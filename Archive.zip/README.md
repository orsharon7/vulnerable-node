Vulnerable Node Project (Edited Version)
===============

![Logo](https://raw.githubusercontent.com/cr0hn/vulnerable-node/master/images/logo-small.png)

*Vulnerable Node: A very vulnerable web site written in NodeJS. This is an edited version by Or Sharon to demonstrate GitHub Advanced Security capabilities and features.*

Codename | PsEA
-------- | ----
Version | 1.0
Code | https://github.com/cr0hn/vulnerable-node
Issues | https://github.com/cr0hn/vulnerable-node/issues/
Original Author | Daniel Garcia (cr0hn) - @ggdaniel
Edited by | Or Sharon