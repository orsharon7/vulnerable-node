CREATE DATABASE vulnerablenode;
GRANT ALL PRIVILEGES ON DATABASE vulnerablenode TO postgres;